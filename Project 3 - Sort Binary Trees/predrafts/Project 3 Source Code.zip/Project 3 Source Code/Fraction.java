
/**
 * This class defines fractions. It should have a constructor that accepts a string representation of a fraction and a toString method.
 * It must implement the Comparable interface, which means a compareTo method is also required.
 * 
 * @author Nabeel Hussain
 */
@SuppressWarnings("rawtypes")
public class Fraction implements Comparable
{
	private String fraction; // String that will hold the string representation of a fraction. 
	
	/**
	 * Constructor that accepts a valid string representation of a fraction.
	 * 
	 * @param frac string representation of a fraction
	 */
	public Fraction(String frac)
	{
		fraction = frac;
	}
    
	/**
	 * Compare method, which will compare two fractions. 
	 * 
	 * @return an integer value of 1 if a is greater than b, 0 if a is equal to b, and -1 if a is less than b.
	 */
	@Override
	public int compareTo(Object o)
	{
		Float numerator;  
		Float denominator;
		
		//Take the string representation of the fraction from the constructor, and splits the numerator and denominator, using the "/" as a delimiter 
		String values[] = fraction.split("/");
		
		numerator = Float.valueOf(values[0]);
		denominator = Float.valueOf(values[1]);
		// Store the value that needs to be compared
		Float a = numerator/denominator;
		
		
		
		//Take the string representation of the fraction in the methods parameter, and splits the numerator and denominator, using the "/" as a delimiter 
		String s = o.toString();
		values = s.split("/");
		
		numerator = Float.valueOf(values[0]);
		denominator = Float.valueOf(values[1]);
		// Store the value that the first fraction is being compared to. 
		Float b = numerator/denominator;
		
		
		// returns an integer value of 1 if  fraction a is greater than  fraction b
		if(a < b)
		{
			return -1;
		}
		// If the previous number is equal to the next number being compared, then return 0
		else if(a == b)
		{
			return 0;
		}
		// return a 1 in all other scenarios, which will signify that the fraction a is greater than fraction b being compared. 
		else
		{
			return 1;
		}	
	}
	
	 
	/**
	 * @return the string representation of the fraction
	 */
	@Override
	public String toString()
	 {
		// TODO Auto-generated method stub
		return fraction;
	}
}
